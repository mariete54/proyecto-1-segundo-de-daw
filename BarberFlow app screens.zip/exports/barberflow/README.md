# BarberFlow

Aplicación web mobile-first de barbería, construida con React 19, TypeScript, Vite 8 y Tailwind CSS 4.

## Pantallas

- Registro e inicio de sesión.
- Dashboard.
- Selección de servicio, fecha y hora de reserva.
- Detalle de la cita.
- Perfil y preferencias.
- Planes de suscripción.
- Cierre de sesión.

El nombre introducido en el registro se muestra en el dashboard, perfil y detalle de la cita.

## Requisitos

- Node.js 22.
- pnpm 10.34.3.

## Instalación y desarrollo

```sh
pnpm install --frozen-lockfile
pnpm dev
```

Abre la URL local que muestra Vite en la terminal.

## Compilación

```sh
pnpm build
pnpm preview
```

La compilación genera `dist/`. No incluyas `node_modules/` ni `dist/` en Git.

## Formato

```sh
pnpm format
```

## Estructura

```text
src/
  App.tsx         # Pantallas, navegación y estado de interfaz
  index.css       # Tema oscuro, fuentes y estilos globales
  main.tsx        # Punto de entrada React
  vite-env.d.ts   # Tipos de Vite
index.html
vite.config.ts
tsconfig.json
package.json
pnpm-lock.yaml
```

Esta exportación utiliza una configuración Vite independiente, sin plugins ni archivos privados del entorno de Figma Make.

## Estado real del proyecto

Este proyecto es un **prototipo frontend**. No incluye servidor, base de datos relacional, autenticación segura, roles de cliente/barbero ni cobros reales.

- El registro y login son simulados: no se verifican credenciales ni se crean cuentas en un servidor.
- El nombre y la navegación se mantienen en memoria y se reinician al recargar la página.
- Guardar el perfil muestra una confirmación, pero no persiste los datos en una base de datos.
- La selección de planes es visual y no contrata ni cobra una suscripción.
- La reserva y su confirmación utilizan datos de demostración; las selecciones no se guardan ni se sincronizan completamente con el detalle.
- Algunos botones informativos (cancelación, historial, contacto y otros) no tienen una operación real implementada.

Para producción es necesario implementar API, persistencia, validación en servidor, autenticación y autorización por roles.

## Recursos externos

Las fuentes se cargan desde Google Fonts y las fotografías desde Unsplash; necesitan conexión a Internet.

Fotografías usadas:

- Allef Vinicius: imagen `1503951914875-452162b0f3f1`.
- Nathon Oski: imagen `1585747860715-2ba37e788b70`.
- Joshua Lawrence: imagen `1621645582931-d1d3e6564943`.

Las URLs de las fotografías están en `src/index.css`.

## Subir a GitHub

1. Descomprime el ZIP y abre la carpeta `barberflow`.
2. Crea un repositorio vacío en GitHub, sin README inicial.
3. Desde esa carpeta ejecuta:

```sh
git init
git add .
git commit -m "Añadir prototipo BarberFlow"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/barberflow.git
git push -u origin main
```

Sustituye `TU_USUARIO` y el nombre del repositorio por los tuyos.

## Publicación

Subir el código a GitHub no publica automáticamente la aplicación.

En un alojamiento compatible con Vite:

- Instalación: `pnpm install --frozen-lockfile`.
- Compilación: `pnpm build`.
- Carpeta de salida: `dist`.

Para GitHub Pages, publica el contenido de `dist` usando un flujo de despliegue o la herramienta de publicación elegida.
