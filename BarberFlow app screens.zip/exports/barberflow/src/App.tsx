import { useState, type FormEvent, type ReactNode } from "react";

type Screen = "auth" | "dashboard" | "booking" | "detail" | "profile" | "plans";
type IconName =
  | "arrow"
  | "calendar"
  | "check"
  | "chevron"
  | "clock"
  | "cut"
  | "home"
  | "logout"
  | "menu"
  | "plus"
  | "scissors"
  | "spark"
  | "user";

const iconPaths: Record<IconName, ReactNode> = {
  arrow: <path d="m15 18-6-6 6-6" />,
  calendar: (
    <>
      <path d="M8 2v4M16 2v4M3 9h18" />
      <rect width="18" height="18" x="3" y="4" rx="3" />
    </>
  ),
  check: <path d="m5 12 4 4L19 6" />,
  chevron: <path d="m9 18 6-6-6-6" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  cut: (
    <>
      <circle cx="6" cy="17" r="3" />
      <circle cx="6" cy="7" r="3" />
      <path d="m8.6 8.5 10.8 8.8M8.6 15.5 19.4 6.7" />
    </>
  ),
  home: (
    <>
      <path d="m3 11 9-8 9 8" />
      <path d="M5 10v10h14V10M9 20v-6h6v6" />
    </>
  ),
  logout: (
    <>
      <path d="M10 17l5-5-5-5M15 12H3" />
      <path d="M14 4h5a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-5" />
    </>
  ),
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  plus: <path d="M12 5v14M5 12h14" />,
  scissors: (
    <>
      <circle cx="6" cy="7" r="3" />
      <circle cx="6" cy="17" r="3" />
      <path d="m8.6 8.5 11 9M8.6 15.5l5.2-4.2M14.8 10.5 20 6" />
    </>
  ),
  spark: <path d="m12 3 1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3Z" />,
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </>
  ),
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg
      aria-hidden="true"
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.8"
    >
      {iconPaths[name]}
    </svg>
  );
}

const services = [
  { name: "Corte Signature", duration: "45 min", price: "18 €", icon: "cut" as IconName },
  { name: "Corte + Barba", duration: "60 min", price: "26 €", icon: "scissors" as IconName },
  { name: "Ritual de barba", duration: "30 min", price: "14 €", icon: "spark" as IconName },
];

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <button
      className="group flex items-center gap-3 text-left"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      type="button"
    >
      <span
        className={`grid place-items-center rounded-full border border-gold/60 bg-[#17110f] text-white transition-transform group-hover:rotate-6 ${compact ? "size-9" : "size-11"}`}
      >
        <Icon name="scissors" size={compact ? 17 : 20} />
      </span>
      <span>
        <span className="block font-display text-xl font-semibold leading-none tracking-tight">BarberFlow</span>
        {!compact && (
          <span className="mt-1 block text-[9px] font-bold uppercase tracking-[0.28em] text-muted">
            Tu estilo, a tu ritmo
          </span>
        )}
      </span>
    </button>
  );
}

function AuthScreen({ currentName, onEnter }: { currentName: string; onEnter: (name: string) => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [showPassword, setShowPassword] = useState(false);
  const [fullName, setFullName] = useState("");

  function submit(event: FormEvent) {
    event.preventDefault();
    onEnter(mode === "register" && fullName.trim() ? fullName.trim() : currentName);
  }

  return (
    <main className="auth-shell min-h-screen">
      <section className="relative flex min-h-[36vh] flex-col overflow-hidden bg-blue p-6 text-white md:min-h-screen md:w-[48%] md:p-12 lg:p-16">
        <div className="relative z-10">
          <Brand />
        </div>
        <div className="relative z-10 mt-auto max-w-xl pt-20 md:pb-8">
          <p className="mb-5 hidden text-xs font-bold uppercase tracking-[0.28em] text-white/60 md:block">
            Barbería contemporánea
          </p>
          <h1 className="max-w-lg font-display text-[clamp(2.7rem,5vw,5.7rem)] font-medium leading-[0.88] tracking-[-0.055em]">
            Menos esperas.
            <br />
            Más <span className="font-serif italic text-gold">estilo.</span>
          </h1>
          <p className="mt-6 max-w-md text-sm leading-6 text-white/65 md:text-base">
            Tu barbería, siempre a mano. Reserva, gestiona tu plan y vuelve a sentirte tú.
          </p>
        </div>
        <div className="barber-lines" />
        <div className="absolute -bottom-24 -right-24 size-80 rounded-full border border-white/10" />
        <div className="absolute -bottom-10 -right-10 size-52 rounded-full border border-white/10" />
      </section>

      <section className="flex flex-1 items-center justify-center bg-cream px-6 py-10 md:min-h-screen md:px-12">
        <div className="w-full max-w-md">
          <div className="mb-9 flex rounded-full bg-[#171310] p-1.5 shadow-soft">
            {(["login", "register"] as const).map((item) => (
              <button
                className={`flex-1 rounded-full py-3 text-sm font-semibold transition-all ${
                  mode === item ? "bg-blue text-white shadow-sm" : "text-muted hover:text-ink"
                }`}
                key={item}
                onClick={() => setMode(item)}
                type="button"
              >
                {item === "login" ? "Iniciar sesión" : "Crear cuenta"}
              </button>
            ))}
          </div>

          <div className="mb-8">
            <p className="eyebrow">{mode === "login" ? "Bienvenido de nuevo" : "Únete a BarberFlow"}</p>
            <h2 className="mt-3 font-display text-4xl font-semibold tracking-tight text-ink">
              {mode === "login" ? "Tu próxima cita empieza aquí." : "Empieza a cuidarte mejor."}
            </h2>
          </div>

          <form className="space-y-5" onSubmit={submit}>
            {mode === "register" && (
              <label className="field-label">
                Nombre completo
                <span className="field-wrap">
                  <Icon name="user" size={19} />
                  <input
                    onChange={(event) => setFullName(event.target.value)}
                    required
                    placeholder="¿Cómo te llamas?"
                    value={fullName}
                  />
                </span>
              </label>
            )}
            <label className="field-label">
              Correo electrónico
              <span className="field-wrap">
                <span className="text-lg font-light">@</span>
                <input required placeholder="tu@email.com" type="email" />
              </span>
            </label>
            <label className="field-label">
              Contraseña
              <span className="field-wrap">
                <span className="text-lg leading-none">••</span>
                <input
                  minLength={6}
                  required
                  placeholder="Mínimo 6 caracteres"
                  type={showPassword ? "text" : "password"}
                />
                <button
                  className="text-xs font-bold text-blue"
                  onClick={() => setShowPassword((value) => !value)}
                  type="button"
                >
                  {showPassword ? "Ocultar" : "Ver"}
                </button>
              </span>
            </label>
            <button className="primary-button mt-2 w-full" type="submit">
              {mode === "login" ? "Entrar a BarberFlow" : "Crear mi cuenta"}
              <Icon name="chevron" />
            </button>
          </form>
          <p className="mt-6 text-center text-xs leading-5 text-muted">
            Al continuar aceptas los términos de uso y la política de privacidad.
          </p>
        </div>
      </section>
    </main>
  );
}

function SideNav({
  navigate,
  onLogout,
  screen,
}: {
  navigate: (screen: Screen) => void;
  onLogout: () => void;
  screen: Screen;
}) {
  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-ink/8 bg-[#0d0a09] p-7 lg:flex">
      <Brand />
      <nav className="mt-14 space-y-2">
        <NavButton active={screen === "dashboard"} icon="home" label="Inicio" onClick={() => navigate("dashboard")} />
        <NavButton active={screen === "booking"} icon="calendar" label="Reservar cita" onClick={() => navigate("booking")} />
        <NavButton active={screen === "detail"} icon="clock" label="Mis citas" onClick={() => navigate("detail")} />
        <NavButton active={screen === "profile"} icon="user" label="Mi perfil" onClick={() => navigate("profile")} />
      </nav>
      <div className="mt-auto rounded-3xl bg-[#17110f] p-5 text-white">
        <span className="mb-4 grid size-9 place-items-center rounded-full bg-gold text-ink">
          <Icon name="spark" size={17} />
        </span>
        <p className="font-display text-xl font-medium">Flow Club</p>
        <p className="mt-1 text-xs leading-5 text-white/55">2 cortes al mes y prioridad al reservar.</p>
        <button className="mt-4 text-xs font-bold text-gold" onClick={() => navigate("plans")} type="button">
          Ver mi plan →
        </button>
      </div>
      <button
        className="relative z-10 mt-4 flex items-center gap-3 px-4 py-2 text-xs font-bold text-muted transition hover:text-gold"
        onClick={onLogout}
        type="button"
      >
        <Icon name="logout" size={17} /> Cerrar sesión
      </button>
    </aside>
  );
}

function NavButton({
  active = false,
  icon,
  label,
  onClick,
}: {
  active?: boolean;
  icon: IconName;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition-colors ${
        active ? "bg-blue text-white" : "text-muted hover:bg-[#241b17] hover:text-ink"
      }`}
      onClick={onClick}
      type="button"
    >
      <Icon name={icon} size={19} />
      {label}
    </button>
  );
}

function MobileHeader({ onLogout }: { onLogout: () => void }) {
  return (
    <header className="flex items-center justify-between border-b border-ink/8 bg-cream px-5 py-4 lg:hidden">
      <Brand compact />
      <button
        aria-label="Cerrar sesión"
        className="grid size-10 place-items-center rounded-full bg-[#171310] text-gold shadow-soft"
        onClick={onLogout}
        title="Cerrar sesión"
        type="button"
      >
        <Icon name="logout" />
      </button>
    </header>
  );
}

function BottomNav({ screen, navigate }: { screen: Screen; navigate: (screen: Screen) => void }) {
  const items: { icon: IconName; label: string; target: Screen }[] = [
    { icon: "home", label: "Inicio", target: "dashboard" },
    { icon: "calendar", label: "Reservar", target: "booking" },
    { icon: "clock", label: "Citas", target: "detail" },
    { icon: "user", label: "Perfil", target: "profile" },
  ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 flex justify-around border-t border-ink/8 bg-[#171310]/95 px-2 pb-[max(0.65rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur lg:hidden">
      {items.map((item) => (
        <button
          className={`flex min-w-16 flex-col items-center gap-1 text-[10px] font-bold ${
            screen === item.target ? "text-blue" : "text-muted"
          }`}
          key={item.label}
          onClick={() => navigate(item.target)}
          type="button"
        >
          <span className={`grid h-7 w-12 place-items-center rounded-full ${screen === item.target ? "bg-blue/10" : ""}`}>
            <Icon name={item.icon} size={18} />
          </span>
          {item.label}
        </button>
      ))}
    </nav>
  );
}

function Dashboard({ navigate, userName }: { navigate: (screen: Screen) => void; userName: string }) {
  const firstName = userName.split(" ")[0];
  return (
    <div className="page-container">
      <header className="flex items-start justify-between gap-6">
        <div>
          <p className="eyebrow">Miércoles, 16 de abril</p>
          <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight md:text-5xl">
            Buenos días, <span className="font-serif italic text-blue">{firstName}.</span>
          </h1>
        </div>
        <button className="hidden size-11 place-items-center rounded-full bg-[#171310] shadow-soft md:grid" type="button">
          <Icon name="user" />
        </button>
      </header>

      <section className="hero-card mt-8 overflow-hidden rounded-[2rem] bg-blue text-white md:mt-10">
        <div className="relative z-10 max-w-xl p-7 md:p-10">
          <p className="text-[10px] font-bold uppercase tracking-[0.25em] text-gold">Tu próxima cita</p>
          <h2 className="mt-4 font-display text-3xl font-medium md:text-4xl">Corte Signature</h2>
          <div className="mt-6 flex flex-wrap gap-x-7 gap-y-3 text-sm text-white/75">
            <span className="flex items-center gap-2"><Icon name="calendar" size={17} /> Viernes, 18 abril</span>
            <span className="flex items-center gap-2"><Icon name="clock" size={17} /> 18:30 h</span>
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <button className="rounded-full bg-[#171310] px-5 py-3 text-xs font-bold text-ink transition hover:bg-gold" onClick={() => navigate("detail")} type="button">
              Ver detalles
            </button>
            <button className="rounded-full border border-white/20 px-5 py-3 text-xs font-bold text-white transition hover:bg-[#241b17]/10" type="button">
              Cambiar cita
            </button>
          </div>
        </div>
        <div className="hero-monogram">18</div>
      </section>

      <section className="mt-10">
        <div className="mb-5 flex items-end justify-between">
          <div>
            <p className="eyebrow">Todo bajo control</p>
            <h2 className="mt-2 font-display text-3xl font-semibold">Tu espacio</h2>
          </div>
          <button className="text-xs font-bold text-blue" type="button">Ver todo</button>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          <button className="action-card group" onClick={() => navigate("booking")} type="button">
            <span className="icon-bubble bg-gold/25 text-ink"><Icon name="plus" /></span>
            <span>
              <strong>Nueva reserva</strong>
              <small>Elige servicio, día y hora</small>
            </span>
            <Icon name="chevron" size={18} />
          </button>
          <button className="action-card group" onClick={() => navigate("detail")} type="button">
            <span className="icon-bubble bg-blue/10 text-blue"><Icon name="clock" /></span>
            <span>
              <strong>Mi historial</strong>
              <small>12 visitas este año</small>
            </span>
            <Icon name="chevron" size={18} />
          </button>
          <button className="action-card group sm:col-span-2 xl:col-span-1" onClick={() => navigate("plans")} type="button">
            <span className="icon-bubble bg-[#dce6d9] text-[#315039]"><Icon name="spark" /></span>
            <span>
              <strong>Suscripción</strong>
              <small>Plan Flow activo</small>
            </span>
            <Icon name="chevron" size={18} />
          </button>
        </div>
      </section>

      <section className="mt-10 rounded-[1.75rem] border border-ink/8 bg-[#171310] p-6 md:p-8">
        <div className="flex items-center justify-between">
          <div>
            <p className="eyebrow">Recomendado para ti</p>
            <h2 className="mt-2 font-display text-2xl font-semibold">Mantén el corte impecable</h2>
          </div>
          <span className="hidden rounded-full bg-cream px-4 py-2 text-xs font-bold text-muted sm:block">Cada 3 semanas</span>
        </div>
        <button className="mt-6 flex w-full items-center justify-between border-t border-ink/8 pt-5 text-left" onClick={() => navigate("booking")} type="button">
          <span className="text-sm font-semibold">Reservar para la semana del 5 de mayo</span>
          <span className="grid size-9 place-items-center rounded-full bg-[#17110f] text-white"><Icon name="chevron" size={17} /></span>
        </button>
      </section>
    </div>
  );
}

function Booking({ navigate }: { navigate: (screen: Screen) => void }) {
  const [selectedService, setSelectedService] = useState(0);
  const [selectedDay, setSelectedDay] = useState(1);
  const [selectedTime, setSelectedTime] = useState("18:30");
  const days = [
    ["Jue", "17"],
    ["Vie", "18"],
    ["Sáb", "19"],
    ["Lun", "21"],
    ["Mar", "22"],
  ];
  const times = ["10:00", "11:30", "16:00", "17:15", "18:30", "19:30"];

  return (
    <div className="page-container max-w-5xl">
      <button className="back-button" onClick={() => navigate("dashboard")} type="button">
        <Icon name="arrow" size={17} /> Volver
      </button>
      <header className="mt-7">
        <p className="eyebrow">Nueva reserva</p>
        <h1 className="mt-3 max-w-xl font-display text-4xl font-semibold tracking-tight md:text-5xl">
          Hazte un hueco para <span className="font-serif italic text-blue">sentirte bien.</span>
        </h1>
      </header>

      <div className="mt-10 grid gap-8 xl:grid-cols-[1fr_310px]">
        <div className="space-y-8">
          <section>
            <StepTitle number="01" title="Elige tu servicio" />
            <div className="mt-4 grid gap-3">
              {services.map((service, index) => (
                <button
                  className={`service-option ${selectedService === index ? "selected" : ""}`}
                  key={service.name}
                  onClick={() => setSelectedService(index)}
                  type="button"
                >
                  <span className="icon-bubble"><Icon name={service.icon} /></span>
                  <span className="flex-1 text-left">
                    <strong className="block text-sm">{service.name}</strong>
                    <small className="mt-1 block text-xs text-muted">{service.duration}</small>
                  </span>
                  <strong className="text-sm">{service.price}</strong>
                  <span className="selection-dot"><Icon name="check" size={13} /></span>
                </button>
              ))}
            </div>
          </section>

          <section>
            <StepTitle number="02" title="Elige un día" />
            <div className="mt-4 grid grid-cols-5 gap-2">
              {days.map((day, index) => (
                <button
                  className={`date-option ${selectedDay === index ? "selected" : ""}`}
                  key={day[1]}
                  onClick={() => setSelectedDay(index)}
                  type="button"
                >
                  <span>{day[0]}</span>
                  <strong>{day[1]}</strong>
                </button>
              ))}
            </div>
          </section>

          <section>
            <StepTitle number="03" title="Elige una hora" />
            <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-6">
              {times.map((time) => (
                <button
                  className={`time-option ${selectedTime === time ? "selected" : ""}`}
                  key={time}
                  onClick={() => setSelectedTime(time)}
                  type="button"
                >
                  {time}
                </button>
              ))}
            </div>
          </section>
        </div>

        <aside className="h-fit rounded-[1.75rem] bg-[#17110f] p-6 text-white xl:sticky xl:top-8">
          <p className="text-[10px] font-bold uppercase tracking-[0.23em] text-gold">Resumen</p>
          <div className="my-6 border-y border-white/10 py-5">
            <p className="font-display text-2xl">{services[selectedService].name}</p>
            <p className="mt-2 text-xs text-white/50">{services[selectedService].duration} · Con Marcos</p>
          </div>
          <div className="space-y-4 text-sm">
            <div className="flex justify-between"><span className="text-white/50">Fecha</span><span>Viernes, 18 abril</span></div>
            <div className="flex justify-between"><span className="text-white/50">Hora</span><span>{selectedTime} h</span></div>
            <div className="flex justify-between"><span className="text-white/50">Total</span><strong className="text-gold">{services[selectedService].price}</strong></div>
          </div>
          <button className="mt-7 flex w-full items-center justify-between rounded-full bg-gold px-5 py-3.5 text-sm font-bold text-ink transition hover:bg-[#241b17]" onClick={() => navigate("detail")} type="button">
            Confirmar reserva <Icon name="chevron" size={18} />
          </button>
          <p className="mt-4 text-center text-[10px] leading-4 text-white/40">Cancelación gratuita hasta 12 h antes.</p>
        </aside>
      </div>
    </div>
  );
}

function StepTitle({ number, title }: { number: string; title: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="font-serif text-sm italic text-blue">{number}</span>
      <h2 className="font-display text-xl font-semibold">{title}</h2>
      <span className="h-px flex-1 bg-[#17110f]/8" />
    </div>
  );
}

function BookingDetail({ navigate, userName }: { navigate: (screen: Screen) => void; userName: string }) {
  const firstName = userName.split(" ")[0];
  return (
    <div className="page-container max-w-5xl">
      <button className="back-button" onClick={() => navigate("dashboard")} type="button">
        <Icon name="arrow" size={17} /> Inicio
      </button>
      <div className="mt-7 grid overflow-hidden rounded-[2rem] bg-[#171310] shadow-soft lg:grid-cols-[0.9fr_1.1fr]">
        <section className="relative overflow-hidden bg-blue p-8 text-white md:p-12">
          <div className="absolute -right-20 -top-20 size-60 rounded-full border border-white/10" />
          <div className="absolute -right-7 -top-7 size-40 rounded-full border border-white/10" />
          <span className="relative grid size-12 place-items-center rounded-full bg-gold text-ink">
            <Icon name="check" size={23} />
          </span>
          <p className="relative mt-10 text-[10px] font-bold uppercase tracking-[0.25em] text-gold">Reserva confirmada</p>
          <h1 className="relative mt-4 font-display text-4xl font-medium leading-tight md:text-5xl">Todo listo,<br />{firstName}.</h1>
          <p className="relative mt-5 max-w-xs text-sm leading-6 text-white/60">
            Te esperamos. Hemos enviado todos los detalles a tu correo.
          </p>
          <div className="relative mt-12 border-t border-white/10 pt-6 text-xs text-white/45">
            Código de reserva <strong className="ml-2 text-white">BF-1804-063</strong>
          </div>
        </section>

        <section className="p-7 md:p-12">
          <p className="eyebrow">Detalle de la cita</p>
          <h2 className="mt-3 font-display text-3xl font-semibold">Corte Signature</h2>
          <div className="mt-8 divide-y divide-ink/8">
            <DetailRow icon="calendar" label="Fecha" value="Viernes, 18 de abril" />
            <DetailRow icon="clock" label="Hora" value="18:30 – 19:15 h" />
            <DetailRow icon="user" label="Profesional" value="Marcos Vidal" />
            <DetailRow icon="cut" label="Servicio" value="Corte · 45 min · 18 €" />
          </div>
          <div className="mt-8 rounded-2xl bg-cream p-5">
            <p className="text-xs font-bold text-ink">BarberFlow Studio</p>
            <p className="mt-1 text-xs leading-5 text-muted">Calle del Pez, 24 · Madrid</p>
            <button className="mt-3 text-xs font-bold text-blue" type="button">Cómo llegar →</button>
          </div>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <button className="primary-button flex-1" onClick={() => navigate("booking")} type="button">
              Cambiar cita <Icon name="calendar" size={17} />
            </button>
            <button className="rounded-full border border-ink/10 px-6 py-3.5 text-sm font-bold text-muted transition hover:border-ink/30 hover:text-ink" type="button">
              Cancelar
            </button>
          </div>
        </section>
      </div>
      <div className="mt-6 flex flex-col items-center justify-between gap-3 px-2 text-center text-xs text-muted sm:flex-row sm:text-left">
        <span>¿Necesitas ayuda? Llámanos al 910 234 567</span>
        <button className="font-bold text-blue" onClick={() => navigate("dashboard")} type="button">Volver al inicio</button>
      </div>
    </div>
  );
}

function DetailRow({ icon, label, value }: { icon: IconName; label: string; value: string }) {
  return (
    <div className="flex items-center gap-4 py-5 first:pt-0">
      <span className="grid size-10 place-items-center rounded-full bg-blue/8 text-blue"><Icon name={icon} size={18} /></span>
      <div>
        <p className="text-[10px] font-bold uppercase tracking-wider text-muted">{label}</p>
        <p className="mt-1 text-sm font-semibold text-ink">{value}</p>
      </div>
    </div>
  );
}

function Profile({
  navigate,
  onLogout,
  userName,
}: {
  navigate: (screen: Screen) => void;
  onLogout: () => void;
  userName: string;
}) {
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const nameParts = userName.trim().split(/\s+/);
  const firstName = nameParts[0] || "Cliente";
  const lastName = nameParts.slice(1).join(" ");
  const initials = nameParts.slice(0, 2).map((part) => part[0]).join("").toUpperCase();

  function saveProfile(event: FormEvent) {
    event.preventDefault();
    setEditing(false);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2500);
  }

  return (
    <div className="page-container max-w-5xl">
      <button className="back-button" onClick={() => navigate("dashboard")} type="button">
        <Icon name="arrow" size={17} /> Inicio
      </button>
      <header className="mt-7 flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
        <div>
          <p className="eyebrow">Cuenta de cliente</p>
          <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight md:text-5xl">
            Mi <span className="font-serif italic text-gold">perfil.</span>
          </h1>
        </div>
        <button
          className="w-fit rounded-sm border border-gold/40 px-5 py-3 text-xs font-bold text-gold transition hover:bg-gold hover:text-[#090807]"
          onClick={() => setEditing((value) => !value)}
          type="button"
        >
          {editing ? "Cancelar edición" : "Editar datos"}
        </button>
      </header>

      {saved && (
        <div className="mt-6 flex items-center gap-3 border border-gold/35 bg-gold/10 px-5 py-4 text-sm text-gold">
          <Icon name="check" size={18} /> Tus datos se han guardado correctamente.
        </div>
      )}

      <div className="mt-8 grid gap-6 lg:grid-cols-[280px_1fr]">
        <aside className="border border-gold/25 bg-[#15110f] p-7">
          <div className="grid size-20 place-items-center rounded-full border border-gold/50 bg-[#0d0a09] font-display text-2xl text-gold">
            {initials}
          </div>
          <h2 className="mt-5 font-display text-2xl font-semibold">{userName}</h2>
          <p className="mt-2 text-xs text-muted">Cliente desde marzo de 2024</p>
          <div className="my-6 h-px bg-gold/20" />
          <div className="space-y-4 text-xs">
            <div className="flex justify-between"><span className="text-muted">Visitas</span><strong>18</strong></div>
            <div className="flex justify-between"><span className="text-muted">Plan</span><strong className="text-gold">Flow</strong></div>
            <div className="flex justify-between"><span className="text-muted">Próxima cita</span><strong>18 abr.</strong></div>
          </div>
          <button className="mt-7 w-full border-t border-gold/20 pt-5 text-left text-xs font-bold text-gold" onClick={() => navigate("plans")} type="button">
            Gestionar suscripción →
          </button>
          <button className="mt-4 flex w-full items-center gap-2 text-left text-xs font-bold text-muted transition hover:text-gold" onClick={onLogout} type="button">
            <Icon name="logout" size={15} /> Cerrar sesión
          </button>
        </aside>

        <form className="border border-gold/25 bg-[#15110f] p-6 md:p-8" onSubmit={saveProfile}>
          <div className="flex items-center gap-3 border-b border-gold/20 pb-5">
            <span className="font-serif text-sm italic text-gold">01</span>
            <h2 className="font-display text-xl font-semibold">Datos personales</h2>
          </div>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <ProfileField disabled={!editing} label="Nombre" defaultValue={firstName} />
            <ProfileField disabled={!editing} label="Apellidos" defaultValue={lastName} />
            <ProfileField disabled={!editing} label="Correo electrónico" defaultValue="alejandro@email.com" type="email" />
            <ProfileField disabled={!editing} label="Teléfono" defaultValue="+34 612 345 678" type="tel" />
          </div>
          <div className="mt-9 flex items-center gap-3 border-b border-gold/20 pb-5">
            <span className="font-serif text-sm italic text-gold">02</span>
            <h2 className="font-display text-xl font-semibold">Preferencias</h2>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <label className="flex items-center justify-between border border-gold/15 bg-[#0d0a09] p-4 text-xs font-semibold">
              Recordatorios por correo
              <input defaultChecked className="accent-[#c28d70]" disabled={!editing} type="checkbox" />
            </label>
            <label className="flex items-center justify-between border border-gold/15 bg-[#0d0a09] p-4 text-xs font-semibold">
              Novedades y promociones
              <input className="accent-[#c28d70]" disabled={!editing} type="checkbox" />
            </label>
          </div>
          {editing && (
            <button className="primary-button mt-8 min-w-48" type="submit">
              Guardar cambios <Icon name="check" size={17} />
            </button>
          )}
        </form>
      </div>
    </div>
  );
}

function ProfileField({
  defaultValue,
  disabled,
  label,
  type = "text",
}: {
  defaultValue: string;
  disabled: boolean;
  label: string;
  type?: string;
}) {
  return (
    <label className="field-label">
      {label}
      <span className="field-wrap">
        <input defaultValue={defaultValue} disabled={disabled} type={type} />
      </span>
    </label>
  );
}

function Plans({ navigate }: { navigate: (screen: Screen) => void }) {
  const [selectedPlan, setSelectedPlan] = useState("Flow");
  const plans = [
    {
      name: "Esencial",
      price: "14",
      description: "Para mantener tu estilo sin complicaciones.",
      features: ["1 corte al mes", "Reserva online", "Historial de visitas"],
    },
    {
      name: "Flow",
      price: "25",
      description: "La experiencia completa para cuidarte cada mes.",
      features: ["2 cortes al mes", "Prioridad al reservar", "10% en productos"],
      featured: true,
    },
    {
      name: "Signature",
      price: "39",
      description: "Cuidado premium, siempre que lo necesites.",
      features: ["3 servicios al mes", "Barbero preferente", "Retoques incluidos"],
    },
  ];

  return (
    <div className="page-container max-w-6xl">
      <button className="back-button" onClick={() => navigate("dashboard")} type="button">
        <Icon name="arrow" size={17} /> Inicio
      </button>
      <header className="mx-auto mt-7 max-w-2xl text-center">
        <p className="eyebrow">BarberFlow Club</p>
        <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight md:text-5xl">
          Tu estilo, <span className="font-serif italic text-gold">cada mes.</span>
        </h1>
        <p className="mx-auto mt-5 max-w-lg text-sm leading-6 text-muted">
          Elige el ritmo que mejor encaja contigo. Sin permanencia y con todos tus servicios en un solo lugar.
        </p>
      </header>

      <div className="mt-10 grid gap-5 lg:grid-cols-3">
        {plans.map((plan) => (
          <article
            className={`relative flex flex-col border bg-[#15110f] p-7 transition ${
              selectedPlan === plan.name ? "border-gold shadow-soft" : "border-gold/20 hover:border-gold/50"
            } ${plan.featured ? "lg:-translate-y-3" : ""}`}
            key={plan.name}
          >
            {plan.featured && (
              <span className="absolute right-0 top-0 bg-gold px-3 py-2 text-[9px] font-bold uppercase tracking-widest text-[#090807]">
                Plan actual
              </span>
            )}
            <span className="grid size-11 place-items-center rounded-full border border-gold/40 text-gold">
              <Icon name={plan.featured ? "spark" : "scissors"} size={19} />
            </span>
            <h2 className="mt-6 font-display text-2xl font-semibold uppercase">{plan.name}</h2>
            <p className="mt-3 min-h-10 text-xs leading-5 text-muted">{plan.description}</p>
            <div className="my-6 border-y border-gold/20 py-5">
              <span className="font-display text-5xl font-semibold">{plan.price}€</span>
              <span className="ml-2 text-xs text-muted">/ mes</span>
            </div>
            <ul className="flex-1 space-y-4">
              {plan.features.map((feature) => (
                <li className="flex items-center gap-3 text-xs" key={feature}>
                  <span className="text-gold"><Icon name="check" size={15} /></span>
                  {feature}
                </li>
              ))}
            </ul>
            <button
              className={`mt-8 flex items-center justify-between px-5 py-3.5 text-xs font-bold transition ${
                selectedPlan === plan.name
                  ? "bg-gold text-[#090807]"
                  : "border border-gold/35 text-gold hover:bg-gold hover:text-[#090807]"
              }`}
              onClick={() => setSelectedPlan(plan.name)}
              type="button"
            >
              {selectedPlan === plan.name ? "Plan seleccionado" : "Elegir este plan"}
              <Icon name={selectedPlan === plan.name ? "check" : "chevron"} size={17} />
            </button>
          </article>
        ))}
      </div>

      <section className="mt-8 flex flex-col justify-between gap-5 border border-gold/25 bg-[#0d0a09] p-6 sm:flex-row sm:items-center">
        <div>
          <p className="font-display text-lg font-semibold">¿Tienes alguna duda sobre los planes?</p>
          <p className="mt-1 text-xs text-muted">Te ayudamos a encontrar la opción que mejor encaja contigo.</p>
        </div>
        <button className="w-fit text-xs font-bold text-gold" type="button">Hablar con la barbería →</button>
      </section>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("auth");
  const [userName, setUserName] = useState("Alejandro Hernández");

  if (screen === "auth") {
    return (
      <AuthScreen
        currentName={userName}
        onEnter={(name) => {
          setUserName(name);
          setScreen("dashboard");
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-cream text-ink">
      <SideNav navigate={setScreen} onLogout={() => setScreen("auth")} screen={screen} />
      <MobileHeader onLogout={() => setScreen("auth")} />
      <main className="pb-24 lg:ml-64 lg:pb-0">
        {screen === "dashboard" && <Dashboard navigate={setScreen} userName={userName} />}
        {screen === "booking" && <Booking navigate={setScreen} />}
        {screen === "detail" && <BookingDetail navigate={setScreen} userName={userName} />}
        {screen === "profile" && (
          <Profile navigate={setScreen} onLogout={() => setScreen("auth")} userName={userName} />
        )}
        {screen === "plans" && <Plans navigate={setScreen} />}
      </main>
      <BottomNav navigate={setScreen} screen={screen} />
    </div>
  );
}
